<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require '../funcion.php';
$categorias = new Categorie($db);
$categorias->get_full_arbo(0);


foreach($categorias->cats as $ca){

if($ca['level']==2) {
$data=array('id_parent'=>2,'id_shop_default'=>1,'name'=>''.$ca['label'].'','description'=>''.$ca['label'].'','link_rewrite'=>'link_rewrite_test');
$res = make_categories($data);
if($res < 0) {setEventMessages('Nose pudieron sincronizar las categorias', '', 'errors');exit;}else{
	$db->query('INSERT INTO `llx_ps_caregoria` (`fk_categoria`, `fk_ps_caregoria`, `valor`) VALUES ('.$ca['id'].', '.$res.',"'.$ca['label'].'")');
	setEventMessages('Categorias->'.$ca['label'].' Creada','');
	
	}
}

}
header("Location: ../siclaprestashopindex.php");
//fin las categorias

//*******BLOQUE DE CATEGORIAS ****///





?>