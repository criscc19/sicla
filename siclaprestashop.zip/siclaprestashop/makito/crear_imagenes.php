<?php
require '../../main.inc.php';
/* define('DEBUG', true);
define('PS_SHOP_PATH', 'http://localhost/prestashop');
define('PS_WS_AUTH_KEY', 'UYMRWW17167Q92NP39IK575IJJDE38F7');
require_once('class/PSWebServiceLibrary.php'); */
$sq = 'SELECT rowid,url,token,actualizar from llx_siclaprestashop_ajustes';
$sql = $db->query($sq);

for ($p = 1; $p <= $db->num_rows($sql); $p++) {
$obl = $db->fetch_object($sql);
$rowid = $obl->rowid;
$url = $obl->url;
$token = $obl->token;
$actualizar = $obl->actualizar;
}

define('PS_SHOP_PATH', $url);
define('PS_WS_AUTH_KEY', $token);
define('DEBUG', true);
require_once DOL_DOCUMENT_ROOT.'/siclaprestashop/class/PSWebServiceLibrary.php';


$url = 'http://localhost/prestashop/api/images/products/370';
$image_path = 'http://www.boxpromotions.com/imagenes/0-7999/2008-05.jpg';
$key = $token;
 


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_USERPWD, $token.':');
curl_setopt($ch, CURLOPT_POSTFIELDS, array('image' => new CurlFile($image_path)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
$result = curl_exec($ch);
if (curl_exec($ch) == false) {
echo "Error actualizando imagen en Presashop
";
echo curl_error($ch) . "
";

} else {echo "Imagen subida correctamente en nuestra tienda.
";}
?>