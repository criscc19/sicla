<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination2ValuePair.class.php';
require_once DOL_DOCUMENT_ROOT.'/siclaprestashop/funcion.php';
$pro = $db->query('SELECT * FROM llx_product');

for ($p = 1; $p <= $db->num_rows($pro); $p++) {
$obj = $db->fetch_object($pro);

//cargando producto hijo
$productos = new Product($db);
$productos->fetch($obj->rowid);

if($productos->isVariant())
{
//cargando antributo
$combination = new ProductCombination($db);
$combination->fetchByFkProductChild($obj->rowid);

//$combination->getUniqueAttributesAndValuesByFkProductParent($obj->rowid);
$sqls = 'SELECT
  c.rowid,
  c2v.fk_prod_attr_val,
  c2v.fk_prod_attr,
  c2v.fk_prod_combination,
  pv.value
FROM llx_product_attribute c 
LEFT JOIN llx_product_attribute_combination2val c2v ON c.rowid = c2v.fk_prod_attr
JOIN llx_product_attribute_value pv ON c2v.fk_prod_attr_val=pv.rowid
WHERE c2v.fk_prod_combination = '.$combination->id.' 
ORDER BY c.rang ASC';
$sqv = $db->query($sqls);
$valor_attributo = $db->fetch_object($sqv)->value;		
	
		
//cargando padre
$padre = new Product($db);
$padre->fetch($combination->fk_product_parent);
$id_atributo = $combination->id;
//cargando padre

//obteniedo id attributo prestashop
$id_variante_val = getCombunationValue(trim($valor_attributo));
//obteniendo id producto padre prestashop 
$id_padre = (int)getProduct(trim($padre->ref));
$resp = 0;

if($productos->url !=''){
//crear imagen
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'http://irioma.com/webapp/image.php?url='.$productos->url.'&id='.$id_padre.'',
    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
]);
// Send the request & save response to $resp
$resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
//fin de crear imagen

}

//armando variante
        $data = array(
		'option_id'=>$id_variante_val,
		'id_product'=>$id_padre,
		'price'=>'0',
		'quantity'=>'0',
		'id_default_image'=>(int)$resp,
		'reference'=>$productos->ref
		);

$res = add_combination($data);

unset($resp);
}

if($res > 0) {
	setEventMessages('Variante->'.$productos->ref.' creada','');
	}
else{
	setEventMessages('Error al sincronizar', '', 'errors');}
	
 }
 
/* $imgid = $db->query('SELECT id_img_hijo FROM `llx__prestashop_img` WHERE hijo like "'.trim($v2['ref']).'" LIMIT 1');
$img_id = $db->fetch_object($imgid)->id_img_hijo;
$fk_parent = getProduct(trim($padre->ref));

 */


header("Location: ../siclaprestashopindex.php");

?>

 
<script>
$(document).ready( function () {
    $('#dtabla').DataTable(
	{
	 'language':{
	'sProcessing':     'Procesando...',
	'sLengthMenu':     'Mostrar _MENU_ registros',
	'sZeroRecords':    'No se encontraron resultados',
	'sEmptyTable':     'Ning�n dato disponible en esta tabla',
	'sInfo':           'Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros',
	'sInfoEmpty':      'Mostrando registros del 0 al 0 de un total de 0 registros',
	'sInfoFiltered':   '(filtrado de un total de _MAX_ registros)',
	'sInfoPostFix':    '',
	'sSearch':         'Buscar:',
	'sUrl':            '',
	'sInfoThousands':  ',',
	'sLoadingRecords': 'Cargando...',
	'oPaginate': {
		'sFirst':    'Primero',
		'sLast':     '�ltimo',
		'sNext':     'Siguiente',
		'sPrevious': 'Anterior'
	},
	'oAria': {
		'sSortAscending':  ': Activar para ordenar la columna de manera ascendente',
		'sSortDescending': ': Activar para ordenar la columna de manera descendente'
	}
},
'displayLength': '999999',
  dom: 'Bfrtip',
 buttons: [ 
            { extend: 'copyHtml5', footer: true,orientation: 'landscape',pageSize: 'A4' },
            { extend: 'excelHtml5', footer: true },
            { extend: 'csvHtml5', footer: true },
            { extend: 'pdfHtml5', footer: true,pageSize: 'A4',
			
			 messageTop: 'Productos importados',

			},
			{extend: 'print',footer: true,
			customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '8pt')
                     
 
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( 'font-size', 'inherit' );
                }
			}
			],

	}
	);
} );
</script>