<?php 
require '../main.inc.php';
if(!$user->rights->siclaprestashop->usar){$result=restrictedArea($user,'siclaprestashop');}

$arrayofcss=array(
'/css/main.css',
//'plugins/css/bootstrap.css'
);
$arrayofjs=array(
//'/pos/frontend/plugins/js/bootstrap.js'
);

llxHeader('',$langs->trans("Sincronizacion"),'','',0,0,$arrayofjs,$arrayofcss);
$currency_code = $conf->currency;
print load_fiche_titre($langs->trans("Simcronizacion de productos "));

print '<table width="100%">';
print '<tr>';
print '<td align="center" colspan="7"><h3>PROCESO DE SINCRONIZACION INICIAL DE PRODUCTOS</h3></td>';
print '</tr>';
print '<tr>';
print '<td align="left"><b>Proveedor</b></td>';
if($user->rights->siclaprestashop->crear_c || $user->rights->siclaprestashop->crear_ps_c) { print '<td align="center"><b>Categorias (1)</b></td>';}
if($user->rights->siclaprestashop->crear_p || $user->rights->siclaprestashop->crear_ps_p ) { print '<td align="center"><b>Productos (2)</b></td>';}
if($user->rights->siclaprestashop->crear_a || $user->rights->siclaprestashop->crear_ps_a ) {print '<td align="center"><b>Atrributos (3)</b></td>';}
if($user->rights->siclaprestashop->crear_v || $user->rights->siclaprestashop->crear_ps_v ) {print '<td align="center"><b>Variantes (4)</b></td>';}
if($user->rights->siclaprestashop->crear_s || $user->rights->siclaprestashop->crear_ps_s ) {print '<td align="center"><b>Stock (5)</b></td>';}
if($user->rights->siclaprestashop->crear_pr || $user->rights->siclaprestashop->crear_ps_pr ) {print '<td align="center"><b>Precios (6)</b></td>';}

 print '</tr>';

print '<tr>';
print '<td colspan="7"><hr></td>';
print '</tr>';


print '<tr>';
print '<td align="left"><img src="img/33558.png" height="40px"></td>';
if($user->rights->siclaprestashop->crear_ps_c) { print '<td align="center"><a class="button" href="crear_recursos/ps_crear_categorias.php"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></a></td>';}
if($user->rights->siclaprestashop->crear_ps_p) { print '<td align="center"><a class="button" href="crear_recursos/ps_crear_productos.php"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></a></td>';}
if($user->rights->siclaprestashop->crear_ps_a) { print '<td align="center"><a class="button" href="crear_recursos/ps_crear_attr_valor.php"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></a></td>';}
if($user->rights->siclaprestashop->crear_ps_v) { print '<td align="center"><a class="button" href="crear_recursos/ps_crear_variante.php"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></a></td>';}
if($user->rights->siclaprestashop->crear_ps_s) { print '<td align="center"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></td>';}
if($user->rights->siclaprestashop->crear_ps_pr) { print '<td align="center"><img class="sync" style="cursor:pointer" src="img/sign-sync-icon.png" height="40px"></td>';}

print '</tr>';

print '</table>';
	

	
dol_fiche_end();
llxFooter();

$db->close();
?>
<script>
$( document ).ready(function() {
	
$('.sync').click(function(){
	$('.sync').hide();
	$(this).show();
	$('this').attr('src','img/giphy.gif.png');
	$(this).parent('td').html('<img class="sync" style="cursor:pointer" src="img/ajax-loader.gif" height="20px">');
	$('.button').hide()
	});
	
$('.button').click(function(){
	$('.button').hide()
	$('.sync').hide();	
	});

});
</script>