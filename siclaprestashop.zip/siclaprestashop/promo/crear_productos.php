<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited
require '../../main.inc.php';	
	
/* ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false); */

require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';

$html = file_get_contents('http://www.promocentroamerica.com/exportadb.php?ubk=LA');
//include('nsoap/nusoap.php');
$doc = new DOMDocument();
$doc->loadHTML($html);
$xml = simplexml_import_dom($doc);
$tr = $xml->body->table->tr;
//var_dump($xml->body->table->tr[0]->td->strong);exit;
$i = 0;
$a =0;
$productos = array();

foreach($tr as $v){
$image = str_replace(' ', '-', (string)$v->td[0][0]);
$productos[] = array(
'Item'=>(string)$v->td[0][0],
'Father'=>(string)$v->td[1][0],
'Family'=>(string)$v->td[2][0],
'Nombre'=>(string)$v->td[3][0],
'Descripcion'=>(string)$v->td[4][0],
'Color'=>(string)$v->td[5][0],
'Colors'=>(string)$v->td[6][0],
'Size'=>(string)$v->td[7][0],
'Material'=>(string)$v->td[8][0],
'Capacity'=>(string)$v->td[9][0],
'Baterries'=>(string)$v->td[10][0],
'Printing'=>(string)$v->td[11][0],
'AreaP'=>(string)$v->td[12][0],
'nw'=>(string)$v->td[13][0],
'gw'=>(string)$v->td[14][0],
'height'=>(string)$v->td[15][0],
'width'=>(string)$v->td[16][0],
'leng'=>(string)$v->td[17][0],
'Cantidad'=>(string)$v->td[18][0],
'image'=>'http://www.promocentroamerica.com/Images/Items/'.$image.'.jpg',
);	
unset(
$productos->attributes,
$productos[0]
);


}

//creando array de padres
$padre = array();
$hijo = array();
$caregorias = array();
$clores = array();
foreach($productos as $p){
	
$padre[$p['Father']] = array(
'Item'=>$p['Item'],
'Father'=>$p['Father'],
'Family'=>$p['Family'],
'Nombre'=>$p['Nombre'],
'Descripcion'=>$p['Descripcion'],
'Color'=>$p['Color'],
'Colors'=>$p['Colors'],
'Size'=>$p['Size'],
'Material'=>$p['Material'],
'Capacity'=>$p['Capacity'],
'Baterries'=>$p['Baterries'],
'Printing'=>$p['Printing'],
'AreaP'=>$p['AreaP'],
'nw'=>$p['nw'],
'gw'=>$p['gw'],
'height'=>$p['height'],
'width'=>$p['width'],
'leng'=>$p['leng'],
'Cantidad'=>$p['Cantidad'],
'image'=>$p['image'],
//'stock'=>stock($p['Item'],$client)
);

if($p['Father'] != $p['Item']){
$hijo[$p['Father']] = array(
'Item'=>$p['Item'],
'Father'=>$p['Father'],
'Family'=>$p['Family'],
'Nombre'=>$p['Nombre'],
'Descripcion'=>$p['Descripcion'],
'Color'=>$p['Color'],
'Colors'=>$p['Colors'],
'Size'=>$p['Size'],
'Material'=>$p['Material'],
'Capacity'=>$p['Capacity'],
'Baterries'=>$p['Baterries'],
'Printing'=>$p['Printing'],
'AreaP'=>$p['AreaP'],
'nw'=>$p['nw'],
'gw'=>$p['gw'],
'height'=>$p['height'],
'width'=>$p['width'],
'leng'=>$p['leng'],
'Cantidad'=>$p['Cantidad'],
'image'=>$p['image'],

);	
}

$caregorias[$p['Family']] = array(
'Family'=>$p['Family']
);	

$colores[$p['Color']] = array(
'Color'=>$p['Color']
);	

}
foreach($productos as $p){
	

$sql = $db->query('SELECT * FROM llx_entrepot e WHERE e.ref LIKE "%Promo opcion%"');
$bodega = $db->fetch_object($sq1)->rowid;

foreach($padre as $v){
$prod = new Product($db);
$prod->ref = trim($v['Father']);
$prod->label = $v['Nombre'];
$prod->description = $v['Descripcion'];
$prod->type = 0;
$prod->tva_tx = 13;
$prod->fk_default_warehouse = $bodega;
$prod->url = $v['image'];
$prod->width = $v['width'];
$prod->height = $v['height'];
$prod->size = $v['leng'];
//$prod->weight = ;
$prod->status = 1;
$prod->status_buy = 1;
$prod->default_vat_code = 'TTC';
$id = $prod->create($user);

if($id < 0) {setEventMessages($prod->error, $prod->errors, 'errors');}else{setEventMessages('Producto: '.$v['Father'].' creado');}
/* if($id > 0){
$cat = new categorie($db);
$cat->fetch('',trim($v['categories']['category_name_1']));
$prodc = new Product($db);
$prodc->fetch($id);
$cat->add_type($prodc,'product');
} */
if($id > 0){
$cat = new categorie($db);
$cat->fetch('','Promo opcion');
$prodc = new Product($db);
$prodc->fetch($id);
$cat->add_type($prodc,'product');


/* $ima = explode('/',$v['image']);
$ima_arr = explode('.',$ima[5]);
$ima_nom = $ima_arr[0];
$ima_ext = $ima_arr[1];
$url = $v['image'];
$img_promo = 'img_promo/'.$prodc->ref.'/'.$ima[5];

//bolque crear directorios
if (!file_exists('img_promo/'.$prodc->ref.'')) {
    mkdir('img_promo/'.$prodc->ref.'', 0777, true);
}
if (!file_exists('img_promo/'.$prodc->ref.'/thumbs')) {
    mkdir('img_promo/'.$prodc->ref.'/thumbs', 0777, true);
} 
file_put_contents($img_promo, file_get_contents($url));
$re1 = resize_image($img_promo,'img_promo/'.$prodc->ref.'/thumbs/'.$ima_nom.'_mini.'.$ima_ext,100,110,80);
$re2 = resize_image($img_promo,'img_promo/'.$prodc->ref.'/thumbs/'.$ima_nom.'_small.'.$ima_ext,100,120,80);  */
}

//header("Location: ../siclaprestashopindex.php");


}




//*******REDIMENCIONAR IMAGEN****///
/* function resize_image($file,$target,$w, $h,$imgQuality,$crop=FALSE) {
    list($width, $height) = getimagesize($file);
    $r = $width / $height;
    if ($crop) {
        if ($width > $height) {
            $width = ceil($width-($width*abs($r-$w/$h)));
        } else {
            $height = ceil($height-($height*abs($r-$w/$h)));
        }
        $newwidth = $w;
        $newheight = $h;
    } else {
        if ($w/$h > $r) {
            $newwidth = $h*$r;
            $newheight = $h;
        } else {
            $newheight = $w/$r;
            $newwidth = $w;
        }
    }
    $src = imagecreatefromjpeg($file);
    $dst = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    imagejpeg($dst,$target, $imgQuality);
    return $dst;*/
}
 


