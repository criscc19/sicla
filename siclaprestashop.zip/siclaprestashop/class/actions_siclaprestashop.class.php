<?php
/* Copyright (C) ---Put here your own copyright and developer email---
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file    htdocs/modulebuilder/template/class/actions_siclaprestashop.class.php
 * \ingroup siclaprestashop
 * \brief   Example hook overload.
 *
 * Put detailed description here.
 */

/**
 * Class Actionssiclaprestashop
 */
class ActionsSiclaprestashop
{
    /**
     * @var DoliDB Database handler.
     */
    public $db;

    /**
     * @var string Error code (or message)
     */
    public $error = '';

    /**
     * @var array Errors
     */
    public $errors = array();


	/**
	 * @var array Hook results. Propagated to $hookmanager->resArray for later reuse
	 */
	public $results = array();

	/**
	 * @var string String displayed by executeHook() immediately after return
	 */
	public $resprints;


	/**
	 * Constructor
	 *
	 *  @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
	{
	    $this->db = $db;
	}


	function addMoreActionsButtons($parameters,$object,$action)
	{
global $conf;
if($object->element=='product'){
print '
<div class="inline-block divButAction"><span  class="butAction" onclick="imgact('.$object->id.')"><i class="fa fa-file-image-o"></i> Actualizar imagen </span></div>
<div class="inline-block divButAction">
<div class="butAction" onclick="enviart('.$object->id.')">
<span id="btexto">Crear en la tienda</span>
<img id="imgv" src="'.DOL_URL_ROOT.'/siclaprestashop/img/loader.svg" width="20px" style="display:none">';

print '</div>';

print '</div>';

if (! empty($conf->global->PRODUIT_MULTIPRICES))
{
print '<select id="multiprecio" name="multiprecio">';
foreach($object->multiprices as $k=>$v){
print '<option value="'.$k.'">Precio '.$k.'</option>';	
}
print '</select>';	
}

print '<div class="inline-block divButAction"><span class="butActionDelete" onclick="eliminarp('.$object->id.')">Eliminar de la tienda</span></div>';	
print '<div id="dialog-confirm" title="Eliminar ptoducto de la tienda" style="display:none">Seguro de eliminar el producto?</div>';	
print '<script>

function enviart(id){
$("#btexto").hide();		
precio = $("#multiprecio").val();

        $.ajax({
                data:  {id:id,plevel:precio},
                url:   "'.DOL_URL_ROOT.'/siclaprestashop/ajax/ps_crear_productos.php",
                type:  "post",
                beforeSend: function () {
                       $("#imgv").show();
                },
                success:  function (response) {
						$("#btexto").show();	
	                    $("#imgv").hide();
                        if(response > 0){
						$.jnotify("Procucto creado con id: "+response, 3000);
						}else{$.jnotify("El producto ya existe en la tienda", "error", 3000);}
						
                }
        });



};


function imgact(id){
$("#btexto").hide();		
        $.ajax({
                data:  {id:id},
                url:   "'.DOL_URL_ROOT.'/siclaprestashop/ajax/ps_imagen.php",
                type:  "post",
                beforeSend: function () {
                       $("#imgv").show();
                },
                success:  function (response) {
						$("#btexto").show();	
	                    $("#imgv").hide();
						$.jnotify("Imagen actualizada en la tuenda: "+response, 4000);

						
                }
        });



};



function eliminarp(id){


$( function() {
    $( "#dialog-confirm" ).dialog({
      resizable: false,
      height: "auto",
      width: 400,
      modal: true,
      buttons: {
        "Eliminar": function() {
          $( this ).dialog( "close" );

        $.ajax({
                data:  {id:id,recurso:"products"},
                url:   "'.DOL_URL_ROOT.'/siclaprestashop/ajax/ps_eliminar_producto.php",
                type:  "post",
                beforeSend: function () {
                       $("#imgv").show();
                },
                success:  function (response) {
						$("#btexto").show();	
	                    $("#imgv").hide();
					    $.jnotify(response, 3000);
						
                }
        });		  
		  
        },
        Cancel: function() {
          $( this ).dialog( "close" );
        }
      }
    });
  } );

}

</script>
';

	}
	}
	
function formObjectOptions($parameters,$object,$action){
	if($object->element == 'category'){
	print '<input type="hidden" size="25" id="label" name="label2" value="'.$object->label.'">';	
		}
	
}	
	
	
}
