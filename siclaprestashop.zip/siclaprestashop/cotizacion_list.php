<?php 
require '../main.inc.php';
if(!$user->rights->siclaprestashop->asigcot){$result=restrictedArea($user,'siclaprestashop');}
$form = new Form($db);
$arrayofcss=array(
//'/css/main.css',
//'plugins/css/bootstrap.css'
);
$arrayofjs=array(
///'/pos/frontend/plugins/js/bootstrap.js'
);

llxHeader('',$langs->trans("Listado de cotizaciones"),'','',0,0,$arrayofjs,$arrayofcss);
	$currency_code = $conf->currency;
	print load_fiche_titre($langs->trans("Listado de cotizaciones"));

// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'http://irioma.com/webapp/cotizacion_list.php',
    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
]);
// Send the request & save response to $resp
$resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
$res = json_decode($resp);
;
print '<table width="100%" class="centpercent border">'; 
print '<tr class="liste_titre">';
print '<td>ID</td>';
print '<td>REF</td>';
print '<td>Cliente</td>';
print '<td>Correo</td>';
print '<td>Telefono</td>';
print '<td>Fecha de creacion</td>';
print '<td>Pais</td>';
print '<td>Empresa</td>';
print '<td>Vendedor</td>';
print '<td>Comentario</td>';
print '<td>Divisa</td>';
print '<td></td>';
print '</tr>';
foreach($res as $cot) {
if($cot->pais == 73){$moneda = '<select name="codigo"><option value="USD">DOLARES($)</option><option value="CRC">COLONES(₡)</option></select>';$pais = 'COSTA RICA';}
if($cot->pais == 168){$moneda = '<select name="codigo"><option value="USD">DOLARES($)</option></select>';$pais = 'PANAMÁ';}
if($cot->pais == 'PANAMÁ'){$moneda = '<select name="codigo"><option value="USD">DOLARES($)</option></select>';$pais = 'PANAMÁ';}
if($cot->pais == 'COSTA RICA'){$moneda = '<select name="codigo"><option value="USD">DOLARES($)</option><option value="CRC">COLONES(₡)</option></select>';$pais = 'COSTA RICA';}
print '<tr>';
print '<form action="crear_pedido.php" method="post">';
print '<input type="hidden" name="action" value="crear_pedido">
<input type="hidden" name="id" value="'.$cot->id.'">';
print '<td>'.$cot->id.'</td>';
print '<td>'.$cot->ref.'</td>';
print '<td>'.$cot->firstname.' '.$cot->lastname.'</td>';
print '<td>'.$cot->customer_email.'</td>';
print '<td>'.$cot->telefono.'</td>';
print '<td>'.$cot->date_add.'</td>';
print '<td>'. $pais.'</td>';
print '<td>'.$cot->empresa.'</td>';
print '<td>

'.$form->select_dolusers('', 'fk_user', 1, array($user->id), 0, '', 0, $conf->entity, 0, 0, '', 0, '', 'maxwidth300').'</td>

</td>';
print '<td>'.$cot->comentario.'</td>';
print '<td>'.$moneda.'</td>';
print '<td><input class="button" type="submit" value="Crear"></td>';
print '</form>';
print '</tr>';
print '<tr><td colspan="11"><br><hr></td></tr>';

/* foreach($cot->detalle as $det) {
print '<tr><td>'.$det->product_ref.'</td></tr>';	

} */

} 



print '</table>';



    dol_fiche_end();
    llxFooter();

$db->close();
?>