<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination2ValuePair.class.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/files.lib.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/images.lib.php';
require '../funcion.php';
$id = $_POST['id'];
$prod = new Product($db);
$prod->fetch($id);
$res_p = getProduct($prod->ref);

if($res_p > 0){echo '-1';exit;}
//obteniendo imagen
$sdir = $conf->product->multidir_output[$prod->entity];
$dir = $sdir . '/';
$pdir = '/';
$dir .= get_exdir(0,0,0,0,$prod,'product').$prod->ref.'/';
$pdir .= get_exdir(0,0,0,0,$prod,'product').$prod->ref.'/';


// Defined relative dir to DOL_DATA_ROOT
$relativedir = '';

if ($dir)
{
$relativedir = preg_replace('/^'.preg_quote(DOL_DATA_ROOT,'/').'/', '', $dir);
$relativedir = preg_replace('/^[\\/]/','',$relativedir);
$relativedir = preg_replace('/[\\/]$/','',$relativedir);
}

$dirthumb = $dir.'thumbs/';
$pdirthumb = $pdir.'thumbs/';

$return ='<!-- Photo -->'."\n";
$nbphoto=0;

$filearray=dol_dir_list($dir,"files",0,'','(\.meta|_preview.*\.png)$',$sortfield,(strtolower($sortorder)=='desc'?SORT_DESC:SORT_ASC),1);
$img = $url = str_replace(" ", "%20",$filearray[0]['name']);
$ext = explode('.',$filearray[0]['name']);
$img_nom = $ext[0];
$img_ext = $ext[1];
if(count($filearray) > 0){
$imagen = $_SERVER['HTTP_ORIGIN'].DOL_URL_ROOT.'/documents/produit/'.$prod->ref.'/'.$img.'';	
}
if(count($filearray) <= 0){
$imagen = $_SERVER['HTTP_ORIGIN'].DOL_URL_ROOT.'/public/theme/common/nophoto.png';	
}

if (! empty($conf->global->PRODUIT_MULTIPRICES))
{
$precio = $prod->multiprices[$_POST['plevel']];
}else{$precio = $prod->price;}


$tipo = isVariant($prod->id);

if($tipo == 'padre')
{
$id_img = createImg($idp,$imagen,1);
}

if($tipo == 'hijo')
{
$rescom = (int)getCombination($prod->ref);

$combination = new ProductCombination($db);
$combination->fetchByFkProductChild($prod->id);

//cargando padre
$padre = new Product($db);
$padre->fetch($combination->fk_product_parent);
$id_atributo = $combination->id;
//cargando padre



//obteniendo id producto padre prestashop 
$id_padre = (int)getProduct(trim($padre->ref));

$id_img = createImg($id_padre,$imagen,$cover='');

        $data = array(
		'option_id'=>$id_variante_val,
		'id_product'=>$id_padre,
		'price'=>'0',
		'quantity'=>'0',
		'id_default_image'=>$id_img,
		'reference'=>$prod->ref
		);

$res = add_combination($data);
if($res > 0){echo $res;}
}

//header("Location: ../siclaprestashopindex.php");

function isVariant($id){
global $db;
$sq ='SELECT * FROM `llx_product_attribute_combination` WHERE `fk_product_child` = '.$id.'';
$sql = $db->query($sq);
$cont = $db->num_rows($sql);
if($cont > 0){return 'hijo';}
if($cont== 0){return 'padre';}
}


?>