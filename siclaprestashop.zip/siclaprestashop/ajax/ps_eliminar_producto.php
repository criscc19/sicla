<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination2ValuePair.class.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/files.lib.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/images.lib.php';
require '../funcion.php';
$id = $_POST['id'];
$recurso = $_POST['recurso'];




if($recurso == 'products'){
$prod = new Product($db);
$prod->fetch($id);	
$tipo = isVariant($id);

if($tipo == 'padre')
{
$res_p = getProduct($prod->ref);	
deleteProduct('products',$res_p);	
}

if($tipo == 'hijo')
{
$prod = new Product($db);
$prod->fetch($id);	
$rescom = (int)getCombination($prod->ref);
$param = getCombinationImage($prod->ref);
$resp = deleteImg($param['id_product'],$param['id_image']);
$res = deleteProduct('combinations',$rescom);	

}



}

function isVariant($id){
global $db;
$sq ='SELECT * FROM `llx_product_attribute_combination` WHERE `fk_product_child` = '.$id.'';
$sql = $db->query($sq);
$cont = $db->num_rows($sql);
if($cont > 0){return 'hijo';}
if($cont== 0){return 'padre';}
}



?>