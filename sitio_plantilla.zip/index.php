<?php 
	require('master.inc.php');
	$sq = 'SELECT * FROM llx_user';
	$sql = $db->query($sq);
	
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Bienvenidos</title>
		
		<link rel='stylesheet'   href='https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.css' type='text/css' media='all' />	
		<link rel='stylesheet'   href='../css/bootstrap.min.css' type='text/css' media='all' />
		<link rel='stylesheet'   href='../css/mdb.min.css' type='text/css' media='all' />
		<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
		<script src="https://kit.fontawesome.com/62c4e05a29.js"></script>	
		
		
	</head>
</body>
<body>
</html>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/i18n/es.js'></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.js'></script>
<script type='text/javascript' src='../js/bootstrap.min.js'></script>
<script type='text/javascript' src='../js/mdb.min.js'></script>
<script>
