<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require '../funcion.php';
$pro = $db->query('SELECT * FROM llx_product ORDER BY rowid LIMIT 50');
$productos = new Product($db);
for ($p = 1; $p <= $db->num_rows($pro); $p++) {
$obj = $db->fetch_object($pro);
$productos->fetch($obj->rowid);

if(!$productos->isVariant())
{
    
		$sq1 = $db->query('SELECT c.label  FROM llx_categorie_product cp
		JOIN llx_categorie c ON cp.fk_categorie=c.rowid
		WHERE `fk_product` = '.$productos->id.'');
		$cat_label = $db->fetch_object($sq1)->label;
		//$id_cat = getCategorie(trim($cat_label));

		$data = array(
		'price'=> 0,
		'name'=> $productos->label,
		'description'=>$productos->description,
		'reference'=> $productos->ref,
		'category_id'=> $id_cat,
		'id_category_default'=>$id_cat,
		'quantity'=>0
		);
//$id = make_product($data); 
$id = getProduct($productos->ref);
if($id > 0 && $productos->url !=''){
// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'http://irioma.com/webapp/image.php?url='.$productos->url.'&id='.$id.'&cover=1',
    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
]);
// Send the request & save response to $resp
$resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);


}

if($id < 0) {setEventMessages('No se pudo sincronizar', 'errors');}else{setEventMessages('Sincronizado->'.$productos->ref.'','');}
}



}
header("Location: ../siclaprestashopindex.php");





?>