<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require '../funcion.php';



$pro = $db->query('SELECT p.rowid,p.ref,pc.fk_product_parent,p2.ref parent_ref,ps.reel,ps.fk_entrepot FROM llx_product p
JOIN llx_product_attribute_combination pc ON pc.fk_product_child=p.rowid
JOIN llx_product p2 ON pc.fk_product_parent = p2.rowid
LEFT JOIN llx_product_stock ps ON ps.fk_product = p.rowid
WHERE p.ref NOT LIKE "OLD-%"');

for ($p = 1; $p <= $db->num_rows($pro); $p++) {
$obj = $db->fetch_object($pro);
if($obj->reel !== NULL){
	
$cant=$obj->reel;

}else{$cant=0;}
$cc = strlen($cant);
if($cc <= 4){$cantidad =round($cant, 0, PHP_ROUND_HALF_DOWN);}
else{$cantidad = str_replace(".", "", $cant);}
echo $obj->ref.'=>'.$cantidad.'<br>';
$id_hijo = getCombination(trim($obj->ref));
$id_padre = (int)getProduct(trim($obj->parent_ref));
if($id_hijo > 0 && is_numeric($id_hijo) && $id_padre > 0){
updateStock($id_padre,$id_hijo,$cantidad);

}
 


}






/* $data = array('id'=> 4998,'price'=> 250);
update_combination($data); */


?>

