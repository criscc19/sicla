<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
//require_once DOL_DOCUMENT_ROOT.'/siclaprestashop/funcion.php';	
$xmlDoc = simplexml_load_file('http://print.makito.es:8080/user/xml/ItemDataFile.php?pszinternal=4f781ea0505b41a5562b4f5124afed0a&ldl=esp');
//$xml = simplexml_load_string($xmlDoc, "SimpleXMLElement", LIBXML_NOCDATA);
$json = json_encode($xmlDoc);
$xml = json_decode($json,TRUE);	
//*******BLOQUE DE CATEGORIAS ****///
//var_dump($xml['product'][0]['variants']);exit;
$cont = count($xml['product']);
$colores = array();
$variates = array();

for ($i = 0; $i <= $cont; $i++) {
if(isset($xml['product'][$i]['variants'])){
foreach($xml['product'][$i]['variants']['variant'] as $k=>$v){
if(isset($v['colour']) && !is_array($v['colour'])){
	
$ref = explode($v['colour'],$v['refct']);	
$variantes[$ref[0]][]= array('ref'=>$v['matnr'],'codigo'=>$v['colour'],'atributo'=>$v['colourname'],'talla'=>$v['size'],'imagen'=>$v['image500px']);
$llave = str_replace (' ', '',$v['colour']);
$colores[$llave] = array('color'=>$v['colourname'],'codigo'=>$llave);
} 	
}	
}

}

//creacion de valores de atributos
foreach($colores as $k=>$v){
	if(!is_array($v['color'])){
$objectval = new ProductAttributeValue($db);

		$objectval->fk_product_attribute = 1;
		$objectval->ref = $v['codigo'];
		$objectval->value = $v['color'];	
        $res = $objectval->create($user);
if($res < 0) {setEventMessages($objectval->error, $objectval->errors, 'errors');}else{setEventMessages('Variante: '.$v['color'].' creada');}
}		
}
header("Location: ../siclaprestashopindex.php");
//fin creacion de valores de atributos

//creacion de valores de atributos prestashop
/*         $vari = $db->query('SELECT * FROM `llx_product_attribute_value`');
		for ($s = 1; $s <= $db->num_rows($vari); $s++) {       		
		$variantes = $db->fetch_object($vari);
        $data = array(
		'id_attribute_group'=>'2',
		'name'=>$variantes->value,
		'color'=>'#FFF'
		);
        $res = make_product_options($data);

		}  */


?>

 
<script>
$(document).ready( function () {
    $('#dtabla').DataTable(
	{
	 'language':{
	'sProcessing':     'Procesando...',
	'sLengthMenu':     'Mostrar _MENU_ registros',
	'sZeroRecords':    'No se encontraron resultados',
	'sEmptyTable':     'Ning�n dato disponible en esta tabla',
	'sInfo':           'Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros',
	'sInfoEmpty':      'Mostrando registros del 0 al 0 de un total de 0 registros',
	'sInfoFiltered':   '(filtrado de un total de _MAX_ registros)',
	'sInfoPostFix':    '',
	'sSearch':         'Buscar:',
	'sUrl':            '',
	'sInfoThousands':  ',',
	'sLoadingRecords': 'Cargando...',
	'oPaginate': {
		'sFirst':    'Primero',
		'sLast':     '�ltimo',
		'sNext':     'Siguiente',
		'sPrevious': 'Anterior'
	},
	'oAria': {
		'sSortAscending':  ': Activar para ordenar la columna de manera ascendente',
		'sSortDescending': ': Activar para ordenar la columna de manera descendente'
	}
},
'displayLength': '999999',
  dom: 'Bfrtip',
 buttons: [ 
            { extend: 'copyHtml5', footer: true,orientation: 'landscape',pageSize: 'A4' },
            { extend: 'excelHtml5', footer: true },
            { extend: 'csvHtml5', footer: true },
            { extend: 'pdfHtml5', footer: true,pageSize: 'A4',
			
			 messageTop: 'Productos importados',

			},
			{extend: 'print',footer: true,
			customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '8pt')
                     
 
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( 'font-size', 'inherit' );
                }
			}
			],

	}
	);
} );
</script>