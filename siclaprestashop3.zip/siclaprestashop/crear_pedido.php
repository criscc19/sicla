<?php 
require '../main.inc.php';
require_once DOL_DOCUMENT_ROOT."/commande/class/commande.class.php";
require_once DOL_DOCUMENT_ROOT."/product/class/product.class.php";
require_once DOL_DOCUMENT_ROOT."/societe/class/societe.class.php";
require_once DOL_DOCUMENT_ROOT . '/comm/propal/class/propal.class.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/functions2.lib.php';
$arrayofcss=array(
//'/css/main.css',
//'plugins/css/bootstrap.css'
);
$arrayofjs=array(
///'/pos/frontend/plugins/js/bootstrap.js'
);
$id = GETPOST('id');
llxHeader('',$langs->trans("Creando pedido"),'','',0,0,$arrayofjs,$arrayofcss);
	$currency_code = $conf->currency;
	print load_fiche_titre($langs->trans("Listado de cotizaciones"));

// Get cURL resource
$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'http://irioma.com/webapp/cotizacion_list.php',
    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
]);
// Send the request & save response to $resp
$resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);
$res = json_decode($resp,true);
;
$mascara = $conf->global->COMPANY_ELEPHANT_MASK_CUSTOMER;
$element = 'societe';
$referencia = 'code_client';
$numero = get_next_value($db,$mascara,$element,$referencia ,$where,$soc,$obj->date,'next');

$pais = $res[$id]['pais'];
if($pais==73){$pais=75;};
if($pais==168){$pais=178;};
//comprobando cliente	
$sq = 'SELECT * FROM llx_societe WHERE email="'.trim($res[$id]['customer_email']).'"';
$sql = $db->query($sq);
if($db->num_rows($sql) > 0){
for ($m = 1; $m <= $db->num_rows($sql); $m++) {
$obu = $db->fetch_object($sql);
$soc = new Societe($db);
$soc->fetch($obu->rowid);
$societe = $soc->id;
}
}else{
$soc = new Societe($db);
$soc->nom = $res[$id]['empresa'];
$soc->firstname = $res[$id]['firstname'];
$soc->lastname = $res[$id]['lastname'];
$soc->email = $res[$id]['customer_email'];
$soc->name_alias = $res[$id]['firstname'].' '.$res[$id]['lastname'];
$soc->country_id = $pais;
$soc->client = 1;
$soc->fournisseur = 0;
$soc->status = 1;
$soc->phone = $res[$id]['telefono'];
$soc->code_client = $numero;
$societe = $soc->create($user);
}

if($pais==75){
	$cli = new Societe($db);
	$cli->fetch($societe);
	$cli->set_price_level(1,$user);	

	};
if($pais==178){
	$cli = new Societe($db);
	$cli->fetch($societe);
	$cli->set_price_level(2,$user);	
	};

//comprobando vendedor

if(GETPOST('fk_user') > 0){
$usuario = new User($db);
$usuario->fetch(GETPOST('fk_user'));
}else{
$usuario = $user;
}

$num = count($res[$id]['detalle']);
//var_dump($res[$id]['detalle']);exit;
$i = 0;
$f = 0;
$lineas = array();
for ($e = 1; $e <= $num; $e++) {
$com =  new propal($db);
$com->ref_client = $object->ref_client;
$com->socid = $societe;
$com->datep = date('Y-m-d');
$com->author = $usuario;
$com->multicurrency_code = GETPOST('codigo');
$com->multicurrency_tx = 1;
$com->note_private = $res[$id]['comentario'];
$pais = $res[$id]['pais'];
$currencyRate = new MultiCurrency($db);
$scambio = $currencyRate->getIdAndTxFromCode($db, 'USD');
$dolar = 1 / $scambio[1];


if($res[$id]['detalle'][$i]['porduct_attr_ef'] == ''){$ref = $res[$id]['detalle'][$i]['product_ref'];}
if($res[$id]['detalle'][$i]['porduct_attr_ef'] != ''){$ref = $res[$id]['detalle'][$i]['porduct_attr_ef'];}
$product = new Product($db);
$product->fetch('',trim($ref));


if(GETPOST('codigo') == 'USD' && $pais == 73){
$tvx= 13;
$precio = $product->multiprices[1];
$precio_dolar = $product->multiprices[1] * $dolar;

$multicurrency_total_tva= $precio_dolar * 13 / 100;
$total_ht = ($product->multiprices[1] * $dolar) * $res[$id]['detalle'][$i]['qty'];
$total_tva = $total_ht  * 13 / 100;
$multicurrency_total_ht = $product->multiprices[1] * $res[$id]['detalle'][$i]['qty'];
$total_ttc = $total_ht + $total_tva;
$multicurrency_total_ttc = $multicurrency_total_ht + $multicurrency_total_tva;


}
if(GETPOST('codigo') == 'CRC' && $pais == 73){
$tvx = 13;

$precio = $product->multiprices[1] * $dolar;
$precio_dolar = $product->multiprices[1];
$total_ht = $precio * $res[$id]['detalle'][$i]['qty'];
$multicurrency_total_ht = ($product->multiprices[1] * $res[$id]['detalle'][$i]['qty']);
$multicurrency_total_tva = $multicurrency_total_ht * 13 / 100;
$total_tva = $total_ht * 13 / 100;
$total_ttc = $total_ht + $total_tva;
$multicurrency_total_ttc = $multicurrency_total_ht + $multicurrency_total_tva;

//suma
$precio2 += $product->multiprices[1] * $dolar;
$precio_dolar2 += $product->multiprices[1];
$total_ht2 += $precio2 * $res[$id]['detalle'][$i]['qty'];
$multicurrency_total_ht2 += ($product->multiprices[1] * $res[$id]['detalle'][$i]['qty']);
$multicurrency_total_tva2 = $multicurrency_total_ht2 * 13 / 100;
$total_tva2 += $total_ht2 * 13 / 100;
$total_ttc2 += $total_ht2 + $total_tva2;
$multicurrency_total_ttc2 = $multicurrency_total_ht2 + $multicurrency_total_tva2;
//suma


}



if(GETPOST('codigo') == 'USD' && $pais == 168){
$tvx= 7;
$precio = $product->multiprices[2];
$precio_dolar = $product->multiprices[2];


$total_ht = $product->multiprices[1] * $res[$id]['detalle'][$i]['qty'];
$total_tva = $total_ht * 13 / 100;
$multicurrency_total_ht = $product->multiprices[1] * $res[$id]['detalle'][$i]['qty'];
$multicurrency_total_tva= $multicurrency_total_ht * 13 / 100;
$total_ttc = $total_ht + $total_tva;
$multicurrency_total_ttc = $multicurrency_total_ht + $multicurrency_total_tva;
}


$orderline1=new PropaleLigne($db);
$orderline1->tva_tx=$tvx;
$orderline1->type=0;
$orderline1->label=$product->label;
$orderline1->description=$product->description;
$orderline1->subprice=$precio;
$orderline1->total_ht=$total_ht;
$orderline1->total_tva=$total_tva;
$orderline1->total_ttc=$total_ttc;
$orderline1->multicurrency_subprice= $precio_dolar;
$orderline1->multicurrency_total_ttc=$multicurrency_total_ttc;
$orderline1->multicurrency_total_ht= $multicurrency_total_ht;
$orderline1->multicurrency_total_tva= $multicurrency_total_tva;
$orderline1->multicurrency_total_ttc= $multicurrency_total_ttc;
$orderline1->fk_product=$product->id;
$orderline1->qty=$res[$id]['detalle'][$i]['qty'];
$lineas[]=$orderline1;

$i++;
$f++;

if(GETPOST('codigo') == 'CRC' && $pais == 73){
 $total2 = $multicurrency_total_ttc2 * $dolar;
 $tva2 = $multicurrency_total_tva2 * $dolar;
 $total_ht2 = $multicurrency_total_ht2 * $dolar; 

}


if(GETPOST('codigo') == 'USD' && $pais == 73){

 $tva += $total_tva * $dolar;
 $total += $total_ttc ;
 $total_ht += $total_ht ; 

}


if(GETPOST('codigo') == 'USD' && $pais == 168){
 $tva += $multicurrency_total_tvar;
 $total += $multicurrency_total_ttc;
 $total_ht += $multicurrency_total_ht ; 	
}



}

$com->lines = $lineas;

$idobject=$com->create($usuario);
if(GETPOST('codigo') == 'CRC' && $pais == 73){

$db->query('UPDATE `llx_propal` SET `total` = "'.price2num(price($total2)).'",tva = "'.price2num(price($tva2)).'",total_ht="'.price2num(price($total_ht2)).'" WHERE `llx_propal`.`rowid` = '.$idobject.'');
}

if(GETPOST('codigo') == 'USD' && $pais == 73){

 $db->query('UPDATE `llx_propal` SET `total` = "'.price2num(price($total)).'",tva = "'.price2num(price($tva)).'",total_ht="'.price2num(price($total_ht)).'" WHERE `llx_propal`.`rowid` = '.$idobject.'');
}

if(GETPOST('codigo') == 'USD' && $pais == 168){
 $tva += $multicurrency_total_tvar;
 $total += $multicurrency_total_ttc;
 $total_ht += $multicurrency_total_ht ; 	
}



if($idobject > 0 ){	
    setEventMessages('Cotizacion asignada','');	
	
		// Get cURL resource
		$curl = curl_init();
		// Set some options - we are passing in a useragent too here
		curl_setopt_array($curl, [
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => 'http://irioma.com/webapp/status_cot.php?id='.$id.'',
		CURLOPT_USERAGENT => 'Consular Sample cURL Request'
		]);
		// Send the request & save response to $resp
		$resp = curl_exec($curl);
		// Close request to clear up some resources
		curl_close($curl);
		$res = json_decode($resp,true);
		;


	header("Location: cotizacion_list.php");
    setEventMessages('Cotizacion asignada','');	
	
	
	}else{setEventMessages($com->error, $com->errors, 'errors');"Location: crear_pedido.php";}



/* foreach($cot['detalle'] as $det) {	
echo $det['product_ref'].'<br>';
} */


    dol_fiche_end();
    llxFooter();

$db->close();
?>