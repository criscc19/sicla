<?php
include '../config/config.inc.php';

$url = 'http://www.boxpromotions.com/imagenes/0-7999/3527-05.jpg';
$id_product = '21';

// we have a csv file open
$default_lang = Configuration::get('PS_LANG_DEFAULT');
// looping through products
// this is a single line in the loop

    $image = new Image();
    $image->id_product = (int) $id_product;
    $image->position = Image::getHighestPosition($product->id) + 1;
    //$image->cover =  true;
    $image->add();
	copyImg($id_product, $image->id, $url, 'products');
/*     if (!)) {
        $image->delete();
    } */

function copyImg($id_entity, $id_image, $url, $entity = 'products', $regenerate = true) {
    $tmpfile = tempnam(_PS_TMP_IMG_DIR_, 'ps_import');
    $watermark_types = explode(',', Configuration::get('WATERMARK_TYPES'));


    switch ($entity) {
        default:
        case 'products':
            $image_obj = new Image($id_image);
            $path = $image_obj->getPathForCreation();
            break;
        case 'categories':
            $path = _PS_CAT_IMG_DIR_ . (int) $id_entity;
            break;
        case 'manufacturers':
            $path = _PS_MANU_IMG_DIR_ . (int) $id_entity;
            break;
        case 'suppliers':
            $path = _PS_SUPP_IMG_DIR_ . (int) $id_entity;
            break;
    }
    $url = str_replace(' ', '%20', trim($url));


    // Evaluate the memory required to resize the image: if it's too much, you can't resize it.
    if (!ImageManager::checkImageMemoryLimit($url))
        return false;


    // 'file_exists' doesn't work on distant file, and getimagesize makes the import slower.
    // Just hide the warning, the processing will be the same.
    if (Tools::copy($url, $tmpfile)) {
        ImageManager::resize($tmpfile, $path . '.jpg');
        $images_types = ImageType::getImagesTypes($entity);


        if ($regenerate)
            foreach ($images_types as $image_type) {
                ImageManager::resize($tmpfile, $path . '-' . stripslashes($image_type['name']) . '.jpg', $image_type['width'], $image_type['height']);
                if (in_array($image_type['id_image_type'], $watermark_types))
                    Hook::exec('actionWatermark', array('id_image' => $id_image, 'id_product' => $id_entity));
            }
    }
    else {
        unlink($tmpfile);
        return false;
    }
    unlink($tmpfile);
    return true;
}