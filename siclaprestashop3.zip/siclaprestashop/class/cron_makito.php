<?php
var_dump($_SERVER);exit;