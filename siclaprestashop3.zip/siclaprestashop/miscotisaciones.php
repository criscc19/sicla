<?php 
	require '../main.inc.php';
    require_once DOL_DOCUMENT_ROOT . '/comm/propal/class/propal.class.php';	
	require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
	
	$form = new Form($db);
	
	$arrayofcss=array(
	//'/css/main.css',
	//'plugins/css/bootstrap.css'
	);
	$arrayofjs=array(
	//'/pos/frontend/plugins/js/bootstrap.js'
	);
	
	llxHeader('',$langs->trans("Listado de cotizaciones"),'','',0,0,$arrayofjs,$arrayofcss);
	$currency_code = $conf->currency;
	
	print load_fiche_titre($langs->trans("Cotizaciones"));
print '<form action="miscotisaciones.php" method="POST">';	
if($user->rights->siclaprestashop->vercot) {
	print '<center>Seleccione vendedor: '.$form->select_dolusers($vendedor, 'fk_user', 1, array($vendedor), 0, '', 0, $conf->entity, 0, 0, '', 0, '', 'maxwidth300').'</center>';}
	print '
<br><br><center><span style="font-size: 1.17em;font-weight: bold; color: #620909;">Rango de fecha:</span> &nbsp;&nbsp;';
 
if(isset($_POST['fk_user'])){
$usuario = new User($db);
$usuario->fetch($_POST['fk_user']);
}else{
$usuario = $user;
} 

 
print 'Fecha Inicio &nbsp;';
$form->select_date($ini, 'fecha_ini'.$v->id.'', '', '', '', "", 1, 1);
print '&nbsp;&nbsp; Fecha Final &nbsp;&nbsp;';
$form->select_date($fin, 'fecha_fin'.$v->id.'', '', '', '', "", 1, 1);
print '</center>';
print '<center><br><br><input type="submit" class="button" value="Generar"></center></form>';
print '&nbsp;&nbsp;<br><br>
<center><h2>Mostrando cotizaciones asignadas a: '.$usuario->firstname.' '.$usuario->lastname.'</h2></center>';
	
	
	
	
	
if(isset($_POST['fecha_ini'])&& !$_POST['fecha_ini']==""){	

//$ini = date_create($_POST['fecha_iniyear'].'-'.$_POST['fecha_inimonth'].'-'.$_POST['fecha_iniday']);
$ini = dol_mktime(12, 0, 0, $_POST['fecha_inimonth'], $_POST['fecha_iniday'], $_POST['fecha_iniyear']);
$fecha1 = date('Y-m-d',$ini);
}

if(isset($_POST['fecha_fin'])&& !$_POST['fecha_fin']==""){	
//$fin = date_create($_POST['fecha_finyear'].'-'.$_POST['fecha_finmonth'].'-'.$_POST['fecha_finday']);
$fin = dol_mktime(12, 0, 0, $_POST['fecha_finmonth'], $_POST['fecha_finday'], $_POST['fecha_finyear']);
$fecha2 = date('Y-m-d',$fin);	
}
	
	
	
	
	
	
	
	
print '<table width="100%" class="centpercent border">';
print '<tr class="liste_titre">';
print '<td>Ref</td>';
print '<td>Cliente</td>';
print '<td>Fecha de creacion</td>';
print '</tr>';

if(isset($_POST['fk_user'])){$vendedor = $_POST['fk_user'];}else{$vendedor = $user->id;}

	$cot = new Propal($db);
	$soc = new Societe($db);
	$sql = $db->query('SELECT * FROM llx_propal p WHERE p.date_valid IS NULL AND p.fk_user_author='.$vendedor.' AND datec BETWEEN "'.$fecha1.' 00:00:00.000000" AND "'.$fecha2.' 23:59:59.999999" ORDER BY rowid DESC LIMIT 25');
		for ($p = 1; $p <= $db->num_rows($sql); $p++) {
        $obj = $db->fetch_object($sql);
		$cot->fetch($obj->rowid);
		$soc->fetch($cot->socid);
		print '<tr>';		
		print '<td>'.$cot->getNomUrl(1).'</td>';
		print '<td>'.$soc->getNomUrl(1).'</td>';
		print '<td>'.dol_print_date($db->jdate($obj->datec), 'dayhour', 'tzuser').'</td>';
		print '</tr>';		
		}
print '<table>';

print '<center><h2>Validadas</h2></center>';


print '<table width="100%" class="centpercent border">';
print '<tr class="liste_titre">';
print '<td>Ref</td>';
print '<td>Cliente</td>';
print '<td>Fecha de creacion</td>';

print '</tr>';

	$sql = $db->query('SELECT * FROM llx_propal p WHERE p.date_valid IS NOT NULL AND p.fk_user_author='.$vendedor.' AND datec BETWEEN "'.$fecha1.' 00:00:00.000000" AND "'.$fecha2.' 23:59:59.999999"  ORDER BY rowid DESC LIMIT 25');
		for ($p = 1; $p <= $db->num_rows($sql); $p++) {
        $obj = $db->fetch_object($sql);
		$cot->fetch($obj->rowid);
		$soc->fetch($cot->socid);
		print '<tr>';		
		print '<td>'.$cot->getNomUrl(1).'</td>';
		print '<td>'.$soc->getNomUrl(1).'</td>';
		print '<td>'.dol_print_date($db->jdate($obj->datec), 'dayhour', 'tzuser').'</td>';
		print '</tr>';		
		}
print '<table>';


    dol_fiche_end();
    llxFooter();
	
	$db->close();
?>