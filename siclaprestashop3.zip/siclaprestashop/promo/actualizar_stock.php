<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited	
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';

include('../nusoap/nusoap.php');
function get_stock($ref){
$client = new nusoap_client('http://desktop.promoopcion.com:8095/wsFullFilmentPAN/FullFilmentPAN.asmx?wsdl','wsdl');

$err = $client->getError();

if ($err) {     echo 'Error en Constructor' . $err ; }

$CardCode = 'CTR0003';

$param = array('codigo' =>$ref , 'distribuidor' => $CardCode);

$result = $client->call('existencias', $param);

//print_r($result);

if ($client->fault) {

        echo 'Fallo';

        print_r($result);

} else {        // Chequea errores

        $err = $client->getError();

        if ($err) {             // Muestra el error

                echo 'Error' . $err ;

        } else {                // Muestra el resultado

              if(isset($result['existenciasResult']['Existencia']['Stock'])){
				  return $result['existenciasResult']['Existencia']['Stock'];
				  }else {return 0;}
            
                

        }

}	
}

$sq = 'SELECT * FROM llx_categorie_product cp WHERE cp.fk_categorie=34';
$sql= $db->query($sq);
$bodega = 7;
for($i=1;$i <= $db->num_rows($sql);$i++){
	$obj = $db->fetch_object($sql);
	$prod = new product($db);
	$prod->fetch($obj->fk_product);
	$ref = str_replace("_", " ", $prod->ref);
	$stock = @get_stock($ref);
	
$db->query('DELETE FROM `llx_product_stock` WHERE `fk_product` = '.$prod->id.' AND `fk_entrepot` = '.$bodega.'');	
	
$res = $prod->correct_stock(
$user,
$bodega,//bodega 
$stock,//cantidad
0,//modo
'Actualizacion masiva desde Promo option',
'',
'Actualizacion masiva desde Promo option'
);

if($res < 0) {setEventMessages($prod->error, $prod->errors, 'errors');}else{setEventMessages('Stock'.$v['ref'].' actualizado','');}

sleep(2);
}
