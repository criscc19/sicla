<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0); // 0 = Unlimited	
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';


$ruta = 'irioma.xlsx';
require '../Classes/PHPExcel/IOFactory.php';	
// Cargo la hoja de cálculo
$objPHPExcel = PHPExcel_IOFactory::load($ruta);
//Asigno la hoja de calculo activa
$objPHPExcel->setActiveSheetIndex(0);
//Obtengo el numero de filas del archivo
$numRows = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();
//var_dump($ref);
for ($i = 6; $i <= $numRows; $i++) {
		
		$ref = $objPHPExcel->getActiveSheet(0)->getCell('B'.$i)->getCalculatedValue();
$precio = $objPHPExcel->getActiveSheet(0)->getCell('E'.$i)->getCalculatedValue();

$codigo = trim(str_replace(" ","_",$ref));				
$price_base_type = 'HT';
$vat_tx = '13';
$localtaxes_array = '';	
$npr = 0;
$psq = 0;

$precio1 = $precio * 45/100;
$precio2 = $precio + $precio1;
$precio3 = $precio2 * 95/100;
$precio4 = $precio2 + $precio3;				
				
				
$prod = new Product($db);
$prod->fetch('',$codigo);

$precio11 = $precio * 45/100;
$precio22 =  + $precio11;
$precio33 = $precio22 * 95/100;
$precio44 = price2num($precio22 + $precio33);
				
				
//precio 2 
$precio_panama = price2num($precio * 4);

$prod->updatePrice($precio4, $price_base_type, $user, $vat_tx, $precio4, 1, $npr, $psq, 0, $localtaxes_array, $prod->default_vat_code);
$prod->updatePrice($precio_panama, $price_base_type, $user, $vat_tx, $precio_panama, 2, $npr, $psq, 0, $localtaxes_array, $prod->default_vat_code);


$com = new ProductCombination($db);
$variantes = $com->fetchAllByFkProductParent($prod->id);
foreach($variantes as $v){
$vari = new Product($db);
$vari->fetch($v->fk_product_child);	
$vari->updatePrice($precio4, $price_base_type, $user, $vat_tx, $precio4, 1, $npr, $psq, 0, $localtaxes_array, $prod->default_vat_code);
$vari->updatePrice($precio_panama, $price_base_type, $user, $vat_tx, $precio_panama, 2, $npr, $psq, 0, $localtaxes_array, $prod->default_vat_code);
}


if($prod < 0) {setEventMessages($prod->error, $prod->errors, 'errors');}else{setEventMessages('Precio'.$prod->ref.' actualizado','');}				

			}

