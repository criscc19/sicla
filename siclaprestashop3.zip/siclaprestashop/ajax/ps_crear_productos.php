<?php
set_time_limit(-1);
ini_set('memory_limit', '-1');
require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/genericobject.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/product.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/modules/product/modules_product.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttribute.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductAttributeValue.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination.class.php';
require_once DOL_DOCUMENT_ROOT.'/variants/class/ProductCombination2ValuePair.class.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/files.lib.php';
include_once DOL_DOCUMENT_ROOT .'/core/lib/images.lib.php';
require '../funcion.php';
$id = $_POST['id'];
$prod = new Product($db);
$prod->fetch($id);
$res_p = getProduct($prod->ref);

if($res_p > 0){echo '-1';exit;}
//obteniendo imagen
$sdir = $conf->product->multidir_output[$prod->entity];
$dir = $sdir . '/';
$pdir = '/';
$dir .= get_exdir(0,0,0,0,$prod,'product').$prod->ref.'/';
$pdir .= get_exdir(0,0,0,0,$prod,'product').$prod->ref.'/';


// Defined relative dir to DOL_DATA_ROOT
$relativedir = '';

if ($dir)
{
$relativedir = preg_replace('/^'.preg_quote(DOL_DATA_ROOT,'/').'/', '', $dir);
$relativedir = preg_replace('/^[\\/]/','',$relativedir);
$relativedir = preg_replace('/[\\/]$/','',$relativedir);
}

$dirthumb = $dir.'thumbs/';
$pdirthumb = $pdir.'thumbs/';

$return ='<!-- Photo -->'."\n";
$nbphoto=0;

$filearray=dol_dir_list($dir,"files",0,'','(\.meta|_preview.*\.png)$',$sortfield,(strtolower($sortorder)=='desc'?SORT_DESC:SORT_ASC),1);
$img = $url = str_replace(" ", "%20",$filearray[0]['name']);
$ext = explode('.',$filearray[0]['name']);
$img_nom = $ext[0];
$img_ext = $ext[1];
if(count($filearray) > 0){
$imagen = $_SERVER['HTTP_ORIGIN'].DOL_URL_ROOT.'/documents/produit/'.$prod->ref.'/'.$img.'';	
}
if(count($filearray) <= 0){
$imagen = $_SERVER['HTTP_ORIGIN'].DOL_URL_ROOT.'/public/theme/common/nophoto.png';	
}

if (! empty($conf->global->PRODUIT_MULTIPRICES))
{
$precio = $prod->multiprices[$_POST['plevel']];
}else{$precio = $prod->price;}


$tipo = isVariant($prod->id);

if($tipo == 'padre')
{
		$sq1 = $db->query('SELECT c.label  FROM llx_categorie_product cp
		JOIN llx_categorie c ON cp.fk_categorie=c.rowid
		WHERE `fk_product` = '.$prod->id.'');
		$cat_label = $db->fetch_object($sq1)->label;
		$id_cate = (int)getCategorie(trim($cat_label));
		if($id_cate > 0){$id_cat = $id_cate;}
		if($id_cate == 0){$id_cat = $categoria;}
		$data = array(
		'price'=> $precio,
		'name'=> $prod->label,
		'description'=>$prod->description,
		'reference'=> $prod->ref,
		'category_id'=> $id_cat,
		'id_category_default'=>$id_cat,
		'quantity'=>0
		);

$idp = make_product($data); 
$id_img = createImg($idp,$imagen,1);
if($idp > 0){echo $idp;}
}

if($tipo == 'hijo')
{
$rescom = (int)getCombination($prod->ref);

if($rescom > 0){
echo '-1';exit;
}	
$combination = new ProductCombination($db);
$combination->fetchByFkProductChild($prod->id);

$sqls = 'SELECT
  c.rowid,
  c2v.fk_prod_attr_val,
  c2v.fk_prod_attr,
  c2v.fk_prod_combination,
  pv.value
FROM llx_product_attribute c 
LEFT JOIN llx_product_attribute_combination2val c2v ON c.rowid = c2v.fk_prod_attr
JOIN llx_product_attribute_value pv ON c2v.fk_prod_attr_val=pv.rowid
WHERE c2v.fk_prod_combination = '.$combination->id.' 
ORDER BY c.rang ASC';
$sqv = $db->query($sqls);
$valor_attributo = $db->fetch_object($sqv)->value;

//cargando padre
$padre = new Product($db);
$padre->fetch($combination->fk_product_parent);
$id_atributo = $combination->id;
//cargando padre

//obteniedo id attributo prestashop
$id_variante_valu = (int)getCombunationValue(trim($valor_attributo));
		if($id_variante_valu > 0){$id_variante_val = $id_variante_valu;}
		if($id_variante_valu == 0){$id_variante_val = $combinacion;}

//obteniendo id producto padre prestashop 
$id_padre = (int)getProduct(trim($padre->ref));

$id_img = createImg($id_padre,$imagen,$cover='');

        $data = array(
		'option_id'=>$id_variante_val,
		'id_product'=>$id_padre,
		'price'=>'0',
		'quantity'=>'0',
		'id_default_image'=>$id_img,
		'reference'=>$prod->ref
		);

$res = add_combination($data);
if($res > 0){echo $res;}
}

//header("Location: ../siclaprestashopindex.php");

function isVariant($id){
global $db;
$sq ='SELECT * FROM `llx_product_attribute_combination` WHERE `fk_product_child` = '.$id.'';
$sql = $db->query($sq);
$cont = $db->num_rows($sql);
if($cont > 0){return 'hijo';}
if($cont== 0){return 'padre';}
}


?>