<?php 
require '../main.inc.php';
//if(!$user->rights->siclaprestashop->asigcot){$result=restrictedArea($user,'siclaprestashop');}
$form = new Form($db);
$arrayofcss=array(
//'/css/main.css',
//'plugins/css/bootstrap.css'
);
$arrayofjs=array(
///'/pos/frontend/plugins/js/bootstrap.js'
);

if($_POST['accion'] == 'crear'){

$res = $db->query('INSERT INTO `llx_etiquetas`(`valor`) VALUES ("'.$_POST['valor'].'")');
if($res > 0){
header("Location: etiquetas.php");	
}
}

llxHeader('',$langs->trans("Etiquetas"),'','',0,0,$arrayofjs,$arrayofcss);
	$currency_code = $conf->currency;
	print load_fiche_titre($langs->trans("Etiquetas"));

print '<h1>Creacion de etiquetas</h1>';
print '<form method="post" action="etiquetas.php">';
print '<input type="hidden" name="accion" value="crear">';
print 'Escriba un valor: <input type="text" name="valor"><input class="button" type="submit" value="Guardar">';
print '</form><br><br>';
print '
<table class="tagtable liste listwithfilterbefore">
<tr class="liste_titre">
<td>ID</td>
<td>VALOR</td>
</tr>';

$sql = $db->query('SELECT * FROM `llx_etiquetas`');
for($i=1;$i <= $db->num_rows($sql);$i++){
$obj = $db->fetch_object($sql);
print '<tr>
<td>'.$obj->rowid.'</td>
<td>'.$obj->valor.'</td>
</tr>';

}

print '</table>';
    dol_fiche_end();
    llxFooter();

$db->close();
?>